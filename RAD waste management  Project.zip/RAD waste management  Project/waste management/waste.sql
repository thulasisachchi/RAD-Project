-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 17, 2021 at 05:33 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `waste`
--

-- --------------------------------------------------------

--
-- Table structure for table `infectious_waste`
--

CREATE TABLE `infectious_waste` (
  `wasteID` int(200) NOT NULL,
  `typeOfWaste` varchar(200) NOT NULL,
  `object` varchar(200) NOT NULL,
  `typeOfContainer` int(11) NOT NULL,
  `wastePerDay` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `infectious_waste`
--

INSERT INTO `infectious_waste` (`wasteID`, `typeOfWaste`, `object`, `typeOfContainer`, `wastePerDay`) VALUES
(3, 'Sharp', 'Needle', 5, 18),
(4, 'Sharp', 'used ampules', 4, 5),
(5, 'Infector waste', 'cotton', 1, 15),
(8, 'surgical item', 'used surgical blades', 7, 10),
(9, 'infector waste', 'glouse', 10, 50),
(12, 'Infector waste', 'cotton', 5, 25),
(13, 'surgical item', 'mask', 2, 10);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `userID` int(11) NOT NULL,
  `userName` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`userID`, `userName`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `non_infectious_waste`
--

CREATE TABLE `non_infectious_waste` (
  `wasteID` int(11) NOT NULL,
  `typeOfWaste` varchar(200) NOT NULL,
  `object` varchar(200) NOT NULL,
  `typeOfContainer` int(11) NOT NULL,
  `wastePerDay` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `non_infectious_waste`
--

INSERT INTO `non_infectious_waste` (`wasteID`, `typeOfWaste`, `object`, `typeOfContainer`, `wastePerDay`) VALUES
(3, 'papers', 'food wraping paper', 5, 50),
(4, 'paper', 'wet paper', 4, 15),
(7, 'food', 'food waste', 2, 12),
(9, 'food', 'dry food', 1, 4);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `infectious_waste`
--
ALTER TABLE `infectious_waste`
  ADD PRIMARY KEY (`wasteID`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`userID`);

--
-- Indexes for table `non_infectious_waste`
--
ALTER TABLE `non_infectious_waste`
  ADD PRIMARY KEY (`wasteID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `infectious_waste`
--
ALTER TABLE `infectious_waste`
  MODIFY `wasteID` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `non_infectious_waste`
--
ALTER TABLE `non_infectious_waste`
  MODIFY `wasteID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
